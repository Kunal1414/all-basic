import java.util.Arrays;

public class AnagramCheck {
   
 
    public static boolean isAnagram(String word, String anagram){       
        if(word.length() != anagram.length()){
            return false;
        }
        char[] chars = word.toCharArray();
       
        for(char c : chars){
        	System.out.println("c : " + c);
        	//System.out.println(anagram.indexOf(c));
            int index = anagram.indexOf(c);
            System.out.println(index);
            if(index != -1){
            	System.out.println("--------------");
            	System.out.println(anagram.substring(0,index));
            	System.out.println(anagram.substring(index +1, anagram.length()));
            	System.out.println(anagram.substring(0,index) + anagram.substring(index +1, anagram.length()));
            	System.out.println("--------------");
                anagram = anagram.substring(0,index) + anagram.substring(index +1, anagram.length());
            }else{
                return false;
            }           
        }
       
        return anagram.isEmpty();
    }
   
   
  /*  public static boolean checkAnagram(String first, String second){
        char[] characters = first.toCharArray();
        StringBuilder sbSecond = new StringBuilder(second);
       
        for(char ch : characters){
            int index = sbSecond.indexOf("" + ch);
            if(index != -1){
                sbSecond.deleteCharAt(index);
            }else{
                return false;
            }
        }
       
        return sbSecond.length()==0 ? true : false;
    }*/
    
       public static void main(String[] args) {
		
    	boolean b = isAnagram("army", "mary");
    	System.out.println(b);
	}
}


