import java.util.LinkedList;

public class Test11 implements Runnable {

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//Thread t = new Thread(this);
		
		int i;
		i =0;
		
		String str = "my name is kunal";
		String str1 = new String(str);
		
		System.out.println((str==str1) + " " + str.equals(str1));
		
		LinkedList  list = new LinkedList();
		list.add("a");
		list.add("b");
		list.add("c");
		
		list.removeFirst();
		System.out.println(list);
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		
	}

}
