import java.security.KeyStore.Entry;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class FindDuplicateCharacters {

	public static void main(String[] args) {
		
		printDuplicateChar("kunalla");

	}
	
	public static void printDuplicateChar(String str) {
		
		char[] arr = str.toCharArray();
		
		Map<Character, Integer> map = new LinkedHashMap<Character, Integer>();
		
		for (char c : arr) {
			if(map.containsKey(c)) {
				
				map.put(c, map.get(c)+1);
			}else {
				map.put(c, 1);
			}
		}
		
		/*Set<Character> set = map.keySet();
		Iterator itr = set.iterator();
		while(itr.hasNext()) {
			Character ch = (Character)itr.next();
			System.out.println("Characher " + ch + " " + "=" + map.get(ch));
		}*/
		
		Set set = map.entrySet();
		Iterator itr = set.iterator();
		while(itr.hasNext()) {
			Map.Entry entry = (Map.Entry)itr.next();
			System.out.println(entry.getKey() + " " + entry.getValue() ) ;
		}
		
	}

}
