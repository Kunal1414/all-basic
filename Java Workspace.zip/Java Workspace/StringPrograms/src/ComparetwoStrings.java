
public class ComparetwoStrings {

	public static void main(String[] args) {
		String str1 = "abc";
        
		String str2 = new String("abc");
		
		String str3 = "abc";
		 
		System.out.println(str1 == str2); //false
		 
		System.out.println(str1.equals(str2)); //true 
		
		System.out.println(str1==str3);

	}

}
