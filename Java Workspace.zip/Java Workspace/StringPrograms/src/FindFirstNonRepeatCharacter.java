import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

public class FindFirstNonRepeatCharacter {

	public static void main(String[] args) {

char ch = findFirstNonRepeatChar("kkuunaalll");
		
		
		
		System.out.println("first non repeat char : " + ch);
	}

	public static char findFirstNonRepeatChar(String str) {

		Map<Character, Integer> map = new LinkedHashMap<Character, Integer>();

		for (int i = 0; i < str.length(); i++) {

			char ch = str.charAt(i);

			if (map.containsKey(ch)) {
				map.put(ch, map.get(ch) + 1);
			} else {
				map.put(ch, 1);
			}

		}

		Set set = map.entrySet();
		Iterator itr = set.iterator();
		
	 for (Map.Entry<Character, Integer> object : map.entrySet()) {
		
		 if(object.getValue() == 1) {
			 return object.getKey();
		 }
	}
	return 0;
		
	}
	
	

}
