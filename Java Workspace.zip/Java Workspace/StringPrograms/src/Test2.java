
public class Test2 {

	public static void main(String[] args) {
		
		String str = "pots";
		int index = str.indexOf('p');
		System.out.println("index : " + index);
		System.out.println(str.substring(1, 4));
		
		System.out.println(str);
	}

}
