
public class StringPermutation {

	public static void main(String[] args) {

		StringPermutation sp = new StringPermutation();
		sp.permutation("abc");
		
	}
	
	public void stringPermutataion(String prefix, String str) {
		
		int length = str.length();
		
		if(length==0) {
	//	System.out.println(prefix);
			//return;
		}
	
		for (int i = 0; i <length; i++) {
			int a = i;
			stringPermutataion(prefix+str.charAt(i), str.substring(0, i)+str.substring(i+1, length));
		}
		//System.out.println("prefix : " + prefix);
		//System.out.println("str : " + str);
		System.out.println(prefix + "  " + str);
		
	}
	
	public void permutation(String str) {
		stringPermutataion("", str);
	}

}
