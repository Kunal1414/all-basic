
public class ReverseStringUsingRecursion {

	public static void main(String[] args) {


		System.out.println("Kunal".length());
		String result = reverse("Kunal");
		System.out.println(result);

	}
	
	
	public static String reverse(String str) {
		
		
		if(str==null || str.length()<=1) {
			return str;
		}
	return	reverse(str.substring(1)) + str.charAt(0);
	}
}
