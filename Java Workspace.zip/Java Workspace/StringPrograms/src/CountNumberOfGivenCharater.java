
public class CountNumberOfGivenCharater {

	public static void main(String[] args) {


		String str = "my name is kunalaaa";
		char[] ch = str.toCharArray();
		int count = 0;
		for (int i = 0; i < ch.length; i++) {
			if(ch[i] == 'a') {
				count++;
			}
		}
		
		System.out.println("the character 'a ' in a given String occured = " + count);
		
	int i1 =	Integer.parseInt("234567");
	System.out.println("integre String to int : " + i1);

	}

}
