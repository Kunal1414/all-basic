
public class VowelCounter {

	public static void main(String[] args) {
		
		String str = "aa pliedddd ee ii oo uu";
		
		  countVowel(str);
		
		
	}
	
	static void countVowel(String str) {
		int countvowels = 0;
		int countconsonant = 0;
		char ch[] = str.toCharArray();
		for (int i = 0; i < ch.length; i++) {
			if(ch[i]=='a' || ch[i]=='e' || ch[i]=='i' || ch[i]=='o' ||ch[i]=='u' ) {
				countvowels++;
			}else if(ch[i]!=' '){
				countconsonant++;
			}
		}
		
		System.out.println("number of vowels : " + countvowels);
		System.out.println("number of consonants : " + countconsonant);
		//return count;
	}

}
