
public class CombinationTest {
	
 public StringBuffer output =   new StringBuffer();
 public final String input;
 
 public CombinationTest(String input) {
	 System.out.println("the input String is " + input);
	 this.input = input;
 }

	public static void main(String[] args) {
		
		CombinationTest c1 =  new CombinationTest("wxyz");
		System.out.println();
		c1.combine();

	}
	
	
	public void combine() {
		combine(0);
	}
	
	public void combine(int  start) {
		
		for (int i = start; i < input.length(); i++) {
			output.append(input.charAt(i));
			System.out.println(output);
			if(i< input.length()) {
				combine(i + 1);
			}
			output.setLength(output.length()-1);
		}
	}

}
