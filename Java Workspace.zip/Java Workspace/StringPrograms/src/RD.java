
public class RD {

	public static void main(String[] args) {

 String str = "Createdparkinglotwith4slots\r\n" + 
 		"YourCarisalreadyparked.\r\n" + 
 		"YourCarisalreadyparked.\r\n" + 
 		"SlotNo.	Registration\r\n" + 
 		"1		registrationNo=KA-01-HH-1234\r\n" + 
 		"2		registrationNo=KA-01-HH-9999";
 
 String str1 = str.toString().trim().replace(" ", "");
 
 System.out.println(str1);

	}

}
