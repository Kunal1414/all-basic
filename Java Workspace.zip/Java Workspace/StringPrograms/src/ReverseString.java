
public class ReverseString {

	public static void main(String[] args) {
		
		 String str = "hello java world";
		 
		 char[] chararray = str.toCharArray();
		 char[] charoutput = new char[chararray.length];
		 String reverseStr;
		 for (int i =  chararray.length -1,j = 0; i>=0; i--, j++) {
			//System.out.print(chararray[i]);
			charoutput[j] = chararray[i];
			
		}
		 reverseStr = String.copyValueOf(charoutput);
	
		 System.out.println("the reverse string : " + reverseStr);
	}

}
