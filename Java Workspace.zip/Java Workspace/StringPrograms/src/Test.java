import java.util.HashMap;
import java.util.Scanner;

public class Test {

	public static void main(String[] args) {
		
		
		/*System.out.println(" Please enter the input string :" );
        Scanner in = new Scanner (System.in);
        String s=in.nextLine();
        char c=firstNonRepeatedCharacter(s);
        System.out.println("The first non repeated character is :  " + c);*/
		
		String testString = "This Is Test";
		System.out.println(testString.length());
		char[] stringToCharArray = testString. toCharArray();
		for (char output : stringToCharArray) {
		System. out. println(output);
		}
        

	}
	
	public static Character firstNonRepeatedCharacter(String s) {
		
		
		HashMap<Character, Integer> map = new HashMap<Character, Integer>();
		
		int i, length;
		Character c;
		length = s.length();
		
		for (int j = 0; j < length; j++) {
			
			c = s.charAt(j);
			if(map.containsKey(c)) {
				map.put(c, map.get(c) + 1);
			}else {
				map.put(c, 1);
			}
			}
		
		for (int j = 0; j < length ; j++) {
			c = s.charAt(j);
			if(map.get(c) == 1) {
				return c;
			}
		}
		
		return null;
		
	}

}
