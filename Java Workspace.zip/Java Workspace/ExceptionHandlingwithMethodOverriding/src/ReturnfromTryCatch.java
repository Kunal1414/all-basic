
public class ReturnfromTryCatch {

	public static int m1() {
   	 
		try {
			int i = 10/0;
			return 5;
		} catch (Exception e) {
			//return 10;
		}
		finally {
			return 15;
		}
		//System.out.println("last line");
    }
	
	
	public static void main(String[] args) {

     int result = m1();

     System.out.println(result);
	}

}
