import java.io.FileNotFoundException;
import java.io.IOException;

class A
{
 
	public void m1() throws FileNotFoundException{
		System.out.println("in m1");
	}
}
  
public class B extends A
{
	
	public void m1() {
		
	}
    public static void main(String[] args)
    {
        A a = new A();
    }
}	