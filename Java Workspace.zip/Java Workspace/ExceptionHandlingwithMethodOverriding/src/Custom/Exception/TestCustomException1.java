package Custom.Exception;

public class TestCustomException1 {
	
	static void validate(int age) throws InvalidAgeException{
		
		if(age < 18) {
			throw new InvalidAgeException("Cannot vote, age is less than 18");
		}else {
			System.out.println("welcome to votiong");
		}
	}
	
		
   public static void main(String[] args) throws InvalidAgeException {
	
	   validate(20);
}

}
