import java.io.*;  


class TestExceptionChild2{  
 
	
	public void m1() throws ArithmeticException{
		System.out.println("in m1()");
	}
	  
  public static void main(String args[]) {  
 
	  TestExceptionChild2 t1 =  new TestExceptionChild2();
	  t1.m1();
  }
}  