import java.io.IOException;

class ParentClass{
	
	public void m1() {
		
	}
}

public class ChildClass extends ParentClass {

	public void m1() throws Exception {
		
	}
	
	public static void main(String[] args) {
		
		System.out.println("Hello");

	}

}
