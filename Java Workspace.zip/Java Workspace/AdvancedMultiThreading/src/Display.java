import java.util.concurrent.locks.ReentrantLock;

public class Display {

	ReentrantLock l = new ReentrantLock();
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*Display d = new Display();
		d.wish("Kunal");*/
	}
	
	public  void  wish(String name) {
		l.lock();
		 int count = 0;
		for (int i = 0; i < 10; i++) {
			
			System.out.print("Good Morning");
			
			try {
				Thread.sleep(5000);
			} catch (Exception e) {
				// TODO: handle exception
			}
			
			System.out.println(" " + name + count++);
		}
		l.unlock();
	}

}
