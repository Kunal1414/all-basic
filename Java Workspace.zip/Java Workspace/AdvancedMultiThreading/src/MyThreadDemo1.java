
public class MyThreadDemo1 extends Thread {

	Display d;
	String name;
	
	public MyThreadDemo1(Display d, String name) {
		this.d = d;
		this.name = name;
		
	}
	
	public  void run() {
		d.wish(name);
	}
}
