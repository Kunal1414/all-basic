
public class SyncronizedDemo1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Display d = new Display();
		MyThreadDemo1 t1 = new MyThreadDemo1(d, "Dhoni");
		MyThreadDemo1 t2 = new MyThreadDemo1(d, "Sachin");
		
		t1.start();
		t2.start();

	}

}
