
public class ThreadGroupExample {

	public static void main(String[] args) {
	
		System.out.println(Thread.currentThread().getThreadGroup());
		
		System.out.println(Thread.currentThread().getThreadGroup().getParent().getName());
		
		ThreadGroup g1 = new ThreadGroup("First Group");
		System.out.println(g1.getParent().getName());
		ThreadGroup g2 = new ThreadGroup(g1, "Second group");
		System.out.println(g2.getParent().getName());

	
		Thread t1 = new Thread(g1, "Thread1");
		Thread t2 = new Thread(g1, "Thread2");
		g1.setMaxPriority(3);
		Thread t3 = new Thread(g1, "Thread3");
		System.out.println(t1.getPriority());
		System.out.println(t2.getPriority());
		System.out.println(t3.getPriority());
		
	}

}
