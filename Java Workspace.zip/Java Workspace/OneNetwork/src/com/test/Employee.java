package com.test;

public class Employee {

private	int empid;
private	String project;
private	String empName;
private	long salary;

public Employee(int empid, String project, String empName,long salary) {
	this.empid = empid;
	this.project =  project;
	this.empName =  empName;
	this.salary = salary;
}

public Employee() {
	
}

public int getEmpid() {
	return empid;
}

public void setEmpid(int empid) {
	this.empid = empid;
}

public String getProject() {
	return project;
}

public void setProject(String project) {
	this.project = project;
}

public String getEmpName() {
	return empName;
}

public void setEmpName(String empName) {
	this.empName = empName;
}

public long getSalary() {
	return salary;
}

public void setSalary(long salary) {
	this.salary = salary;
}
	

}
