package com.test;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

public class MainApp {
 
	public static void main(String[] args) {
		
		List<Employee> list = new ArrayList<>();
		list.add(new Employee(100, "Army Project", "Joy", 120000));
		list.add(new Employee(200, "Army Project", "Jenny", 100000));
		list.add(new Employee(300, "Environment Project", "Jennifer", 90000));
		list.add(new Employee(400, "Mobile Project", "David", 100000));
		
		Map<String, Employee> map = new HashMap<>();
		for (Employee employee : list) {
			Employee currentEmployee = map.get(employee.getProject());
			if(currentEmployee==null || employee.getSalary() > currentEmployee.getSalary()) {
				map.put(employee.getProject(), employee);
			}
		}

		Iterator<Map.Entry<String, Employee>> itr = map.entrySet().iterator();
		
		while (itr.hasNext()) {
			Map.Entry<String, Employee> data = itr.next();
			System.out.println(data.getKey() + " Employee id " + data.getValue().getEmpid() + " Employee name  " + data.getValue().getEmpName() + " " + data.getValue().getSalary());
			
		}
	}

}
