package com.kunal.highestsalaryperproject;

public class Employee {
	
	private int empid;
	private String projectName;
	private String EmpName;
	private long salary;
	public Employee(int empid, String projectName, String empName, long salary) {
		super();
		this.empid = empid;
		this.projectName = projectName;
		EmpName = empName;
		this.salary = salary;
	}
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getEmpName() {
		return EmpName;
	}
	public void setEmpName(String empName) {
		EmpName = empName;
	}
	public long getSalary() {
		return salary;
	}
	public void setSalary(long salary) {
		this.salary = salary;
	}
	
	/*public String toString() {
		return "Employee [empid=" + empid + ", projectName=" + projectName + ", EmpName=" + EmpName + ", salary="
				+ salary + "]";
	}
	*/
	
	
	

}
