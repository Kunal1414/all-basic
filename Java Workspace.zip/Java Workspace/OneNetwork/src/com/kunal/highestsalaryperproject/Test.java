package com.kunal.highestsalaryperproject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

public class Test {

	public static void main(String[] args) {

		ArrayList<Employee> list = new ArrayList<>();
		list.add(new Employee(100, "Army Project", "Joy", 12000));
		list.add(new Employee(200, "Army Project", "Jenny", 18000));
		list.add(new Employee(300, "Env project", "Jennifer", 9000));
		list.add(new Employee(400, "Mobile Project", "David1", 10000));
		list.add(new Employee(500, "Mobile Project", "David", 15000));

		Map<String, Employee> map = new HashMap<>();
		for (Employee employee : list) {
			Employee currentEmp = map.get(employee.getProjectName());
			if (currentEmp == null || employee.getSalary() > currentEmp.getSalary()) {
				map.put(employee.getProjectName(), employee);
			}
		}
		
		Iterator<Map.Entry<String,Employee>> itr = map.entrySet().iterator();
		System.out.println("Employee having higesht slary for department");
		while(itr.hasNext()) {
			Map.Entry<String, Employee> data = itr.next();
			System.out.println(data.getKey() + " " + data.getValue().getEmpid() + " " +  data.getValue().getEmpName() + " " + data.getValue().getSalary());
		}

	}

}
