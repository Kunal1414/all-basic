import java.util.function.Function;

public class Test {

	/*public static int squareIt(int n) {
	
		return n*n;
	}*/
	
	public static void main(String[] args) {
		
		
		/*System.out.println("The square of 4 : " + squareIt(4));
		System.out.println("The square of 5 : " + squareIt(5));*/
		
		Function<Integer, Integer> f = i->(i*i);
		
		System.out.println("The square of 4 : " + f.apply(8));
		System.out.println("The square of 5 : " + f.apply(9));
		
		
		
	}

}
