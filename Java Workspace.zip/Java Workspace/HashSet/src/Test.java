import java.util.HashSet;
import java.util.TreeSet;

public class Test {

	public static void main(String[] args) {

		HashSet<String>  obj1= new HashSet<String>();
        obj1.add(null);
        obj1.add("is");
        obj1.add("Awesome");
      //  obj1.add(null);
        System.out.println(obj1);        

        System.out.println("--------------------");
        
        TreeSet<String>  obj2= new TreeSet<String>();
       // obj2.add(null);
        obj2.add("is");
        obj2.add("Awesome");
        System.out.println(obj2);
	}

}
