package com.sameobject.test;

public class User {
	
	int id;
	String name;
	
	public User(int id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	
	

}
