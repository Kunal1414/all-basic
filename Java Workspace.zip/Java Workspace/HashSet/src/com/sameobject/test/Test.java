package com.sameobject.test;

import java.util.HashSet;
import java.util.Set;

public class Test {

	public static void main(String[] args) {


		User u1 = new User(1, "abc");
		User u2 = new User(1, "abc");
		User u3 = new User(1, "abc");
		User u4 = new User(1, "abc");
		User u5 = new User(1, "abc");
		
		Set<User> set = new HashSet<>();
		set.add(u1);
		set.add(u2);
		set.add(u3);
		set.add(u4);
		set.add(u5);
		
		
		System.out.println(set.size());
		
		
		
		
	}

}
