
public interface Square {

	int calculateSquare(int a);
}
