
public class SquareImpl {

	public static void main(String[] args) {
		int a = 5;
		Square s  = (int x) -> {
			return x * x;
		};
		
		int answer = s.calculateSquare(a);
		System.out.println(answer);

	}

}
