package com.kunal.lowertoupper;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class CovertlowertoupperImpl {

	public static void main(String[] args) {
		
		List<String> list = new ArrayList<>();
		list.add("abc");
		list.add("xyz");
		list.add("lms");
		System.out.println(list);
		Covertlowertoupper clu = (List<String> list1) ->{
			
			List<String> result = new ArrayList<>();
			
			Iterator<String> itr = list1.iterator();
			while(itr.hasNext()) {
				String str = (String) itr.next();
				char[] ch = str.toCharArray();
				for (int i = 0; i < ch.length; i++) {
					if(ch[i] >='a' && ch[i]<='z') {
						ch[i] = (char)((int)ch[i]-32);
					}
				}
				
				String str1 = String.copyValueOf(ch);
				result.add(str1);
				}
			return result;
		};
		
	List<String> finalresul = 	clu.lowerToupper(list);
	
	System.out.println(finalresul);
	}

}
