package com.kunal.lowertoupper;

import java.util.List;

public interface Covertlowertoupper {

	   List<String> lowerToupper(List<String> list);
}
