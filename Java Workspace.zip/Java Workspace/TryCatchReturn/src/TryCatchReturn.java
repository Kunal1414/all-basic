
public class TryCatchReturn {
	
	@SuppressWarnings("finally")
	public static int foo() {
		
		try {
			return 10;
			
		} catch (Exception e) {
			return 20;
		}
		finally {
			//return 30;
		}
		
	
	}

	public static void main(String[] args) {
		
		int i = foo();
		
		System.out.println(" i " + i);

	}

}
