
public interface InterfaceOne {

	int m1();
}
