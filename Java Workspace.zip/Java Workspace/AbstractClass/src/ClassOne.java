
public abstract class ClassOne {
	
	public void m1() {
		
	}
	
	public abstract void m2();
	
	public ClassOne() {
		
	}

	public static void main(String[] args) {
		
		

	}

}
