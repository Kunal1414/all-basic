
public class ClassTwo extends ClassOne {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
   
		 ClassOne c1 =  new ClassOne() 
		
	}

	@Override
	public void m2() {
		// TODO Auto-generated method stub
		
	}

	

}
