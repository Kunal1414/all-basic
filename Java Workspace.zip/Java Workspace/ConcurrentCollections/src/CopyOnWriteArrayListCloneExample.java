import java.util.Iterator;
import java.util.concurrent.CopyOnWriteArrayList;

public class CopyOnWriteArrayListCloneExample {

	public static void main(String[] args) {
		
		CopyOnWriteArrayList cal =  new CopyOnWriteArrayList();
		
		cal.add("A");
		cal.add("B");
		cal.add("C");
		System.out.println(cal);
		
		Iterator itr =  cal.iterator();
		cal.add("D");
		while(itr.hasNext()) {
			String str = (String)itr.next();
			System.out.println(str);
		}
		System.out.println(cal);
	}
}
