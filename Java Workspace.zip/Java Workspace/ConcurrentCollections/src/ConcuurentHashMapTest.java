import java.util.concurrent.ConcurrentHashMap;

public class ConcuurentHashMapTest {

	public static void main(String[] args) {
		
		ConcurrentHashMap  map =  new ConcurrentHashMap();
		map.put(101, "a");
		map.put(102, "b");
		map.putIfAbsent(103, "c");
		map.putIfAbsent(101, "d");
		map.remove(103, "d");
		map.replace(102, "b", "e");
		
		System.out.println(map);

	}

}
