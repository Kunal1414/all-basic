import java.util.ArrayList;
import java.util.concurrent.CopyOnWriteArrayList;

public class CopyOnWriteArrayListTest {

	public static void main(String[] args) {
		
		ArrayList al =  new ArrayList();
		al.add("a");
		al.add("b");
		System.out.println(al);
		
		CopyOnWriteArrayList cal = new CopyOnWriteArrayList();
		cal.addIfAbsent("a");
		cal.addIfAbsent("c");
		System.out.println(cal);
		cal.addAllAbsent(al);
		System.out.println(cal);

	}

}
