import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ConcurentHashMapwithMultiThread extends Thread {
	
 public	static ConcurrentHashMap map = new ConcurrentHashMap();
 
// public	static HashMap map = new HashMap();
	
 public void run() {
	 
	 try {
		Thread.sleep(2000);
	} catch (Exception e) {	}
	 System.out.println("Child Thread updating map");
	 map.put(103, "c");
 }

	public static void main(String[] args) throws InterruptedException {
		
		map.put(101, "a");
		map.put(102, "b");
		
		ConcurentHashMapwithMultiThread t1 = new ConcurentHashMapwithMultiThread();
		t1.start();
		Set s1 = map.keySet();
		Iterator itr = s1.iterator();
		while(itr.hasNext()) {
			Integer i = (Integer)itr.next();
			System.out.println("Main Thread iterating map and current entry is : " + i + " " + map.get(i));
			Thread.sleep(3000);
		}
		System.out.println(map);

	}

}
