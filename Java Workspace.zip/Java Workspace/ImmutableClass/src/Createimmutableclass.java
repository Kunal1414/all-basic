import java.util.Date;

public final class Createimmutableclass {
	
	private final int id;
	private final String name;
	private final String address;
	private final Date date;
	
	public Createimmutableclass(int id, String name, String address, Date date) {
		this.id= id;
		this.name = name;
		this.address = address;
		this.date = date;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}
	

	public Date getDate() {
		return (Date)date.clone();
		//return new Date(date.getTime());
	}

	@Override
	public String toString() {
		return "Createimmutableclass [id=" + id + ", name=" + name + ", address=" + address + ", date=" + date + "]";
	}
	
	
}
