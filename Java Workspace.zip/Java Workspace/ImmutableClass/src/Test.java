import java.util.Date;

public class Test {

	public static void main(String[] args) {
		
		Date d = new Date(2019, 01, 01);
		Createimmutableclass c = new Createimmutableclass(1, "kuna", "pune", d);
		System.out.println(c.toString());
		d.setDate(5);
		
		System.out.println(c.toString());
		

	}

}
