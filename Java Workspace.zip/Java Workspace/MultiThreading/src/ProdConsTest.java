
class A1 {

	int num;
	boolean valueSet = false;

	public synchronized void set(int num) {

		while (valueSet) {
			try {
				wait();
			} catch (Exception e) {
			}
		}
			System.out.println("Set : " + num);
			this.num = num;
			valueSet = true;
			notify();
		
	}

	public synchronized void get() {
		while (!valueSet) {
			try {
				wait();
			} catch (Exception e) {
			}
		}

			System.out.println("Get : " + num);
			valueSet = false;
			notify();
		
	}
}

class producer1 implements Runnable {

	A1 a;

	public producer1(A1 a) {
		this.a = a;

		Thread t1 = new Thread(this, "producer");
		t1.start();
	}

	@Override
	public void run() {

		int i = 0;

		while (true) {
			a.set(i++);
			try {

				Thread.sleep(1000);
			} catch (Exception e) {
				// TODO: handle exception
			}
		}

	}
}

class consumer1 implements Runnable {

	A1 a;

	public consumer1(A1 a) {
		this.a = a;

		Thread t1 = new Thread(this, "consumer");
		t1.start();
	}

	@Override
	public void run() {
		while (true) {
			a.get();
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				// TODO: handle exception
			}
		}

	}
}

public class ProdConsTest {

	public static void main(String[] args) {
		A1 a = new A1();
		new producer1(a);
		new consumer1(a);

	}

}
