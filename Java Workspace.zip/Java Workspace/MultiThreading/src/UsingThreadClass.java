import java.io.IOException;

public class UsingThreadClass extends Thread {
	
	public void run() {
		try {
			System.out.println(Thread.currentThread().getName());  
		} catch (Exception e) {
			// TODO: handle exception
		}
	}

	public static void main(String[] args) throws IOException {
		
		UsingThreadClass t1 = new UsingThreadClass();
		 
		UsingThreadClass t2=new UsingThreadClass();  
		System.out.println("Name of t1:"+t1.getName());  
		System.out.println("Name of t2:"+t2.getName());  
		System.out.println("id of t1:"+t1.getId());  
		
		t1.start();
		t2.start();
		
		Runtime.getRuntime().exec("notepad");//will open a new notepad 

	}

}
