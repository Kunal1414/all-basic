
public class TestContainConcreteMehtod implements ContainConcreteMethod {

	public static void main(String[] args) {
	
		ContainConcreteMethod c = new TestContainConcreteMehtod();
		c.xyz();
		c.xyz1();

	}

	@Override
	public void abc() {
		System.out.println("Calling abstract method implemenatation");
		
	}

}
