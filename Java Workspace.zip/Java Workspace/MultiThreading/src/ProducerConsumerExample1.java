class B{
	
	
	int num;
	boolean valueset = false;
	
	public synchronized void set(int num) {
		
		while(valueset) {
			try {
				wait();
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		
		System.out.println("set : " + num);
		this.num = num;
		valueset = true;
		notify();
		
	}
	
	public synchronized void get() {
		
		while(!valueset){
			try {
				wait();
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		
		System.out.println("get : " + num);
		valueset = false;
		notify();
	}
	
}

class producer11 implements Runnable{
	
	B  b;
	
	public producer11(B b) {
		this.b = b;
		Thread t = new Thread(this, "Producer");
		t.start();
	}
	
	public void run() {
		
		int i = 0;
		while(true) {
			b.set(i++);
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
	}
}

class consumer11  implements Runnable{
	
	B b;
	
	public consumer11(B b) {
		this.b = b;
		Thread t1 = new Thread(this, "Consumer");
		t1.start();
	}
	
	public void run() {
		
		while(true) {
			b.get();
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
	}
}


public class ProducerConsumerExample1 {

	public static void main(String[] args) {
		
		B b = new B();
		new producer11(b);
		new consumer11(b);
		

	}

}
