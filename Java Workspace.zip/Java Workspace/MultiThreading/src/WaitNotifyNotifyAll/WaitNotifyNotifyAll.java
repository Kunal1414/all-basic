package WaitNotifyNotifyAll;

public class WaitNotifyNotifyAll extends Thread{
	
	
	

	public static void main(String[] args){
		 final Cutomer c = new Cutomer();
		WaitNotifyNotifyAll t1 =  new WaitNotifyNotifyAll() {
			public void run() {
				c.withdraw(10000);
			}
		};
		
		WaitNotifyNotifyAll t2 = new WaitNotifyNotifyAll(){
			public void run() {
				c.deposite(15000);
			}
		};
		
		t1.start();
		t2.start();
		
		

	}

}
