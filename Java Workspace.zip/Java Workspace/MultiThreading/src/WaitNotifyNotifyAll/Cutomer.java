package WaitNotifyNotifyAll;

public class Cutomer {
	
	int amount = 10000;
	
    public synchronized void withdraw(int amount){
    	
    	if(this.amount <= amount) {
    		System.out.println("less balance, plz deposit the amount in your acount");
    		try {
				wait();
			} catch (Exception e) {
				// TODO: handle exception
			}
    	}
    		
    		this.amount = this.amount - amount;
    		System.out.println("withdrawal completed");
    	}
    
    
    public synchronized void deposite(int amount) {
    	System.out.println("starting the deposite");
    	this.amount = this.amount + amount;
    	System.out.println("deposite done");
    	notify();
    }

}
