
class AA{
	
	int data;
	boolean value = false;
	
	public synchronized void set(int data) {
		
		while(value) {
			try { wait();} catch (Exception e) {}
		}
		this.data = data;
		System.out.println("Set : " + data);
		value = true;
		notify();
	}
	
	public synchronized void get() {
		while(!value) {
			try { wait();} catch (Exception e) {}
		}
		System.out.println("get : " + data);
		value = false;
		notify();
	}
}

class producer2 implements Runnable{

	AA a;
	 public producer2(AA a) {
		this.a = a;
		Thread t1 =  new Thread(this, "producer");
		t1.start();
		
	}
	
	@Override
	public void run() {
		int i = 0;
		while(true) {
			a.set(i++);
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
	}
	
}

class consumer2 implements Runnable{

	AA a;
	 public consumer2(AA a) {
		this.a = a;
		Thread t2 = new Thread(this, "consumer");
		t2.start();
	}
	
	
	@Override
	public void run() {
		while(true) {
			a.get();
			try {
				Thread.sleep(1000);
			} catch (Exception e) {
				// TODO: handle exception
			}
		}
	}
	
}

public class TestProducerConsumer {

	public static void main(String[] args) {

    AA a = new AA();
    new producer2(a);
    new consumer2(a);
    
	
	}

}
