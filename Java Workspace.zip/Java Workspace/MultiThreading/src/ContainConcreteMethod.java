
public interface ContainConcreteMethod {

	
	 void abc();
	
	default void xyz() {
		System.out.println("In interface1");
	}
	
	default void xyz1() {
		System.out.println("In interface2");
	}
}
