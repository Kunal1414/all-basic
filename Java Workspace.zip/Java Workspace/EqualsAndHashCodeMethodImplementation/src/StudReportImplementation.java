import java.util.HashMap;
import java.util.Map;

public class StudReportImplementation {

	public static void main(String[] args) {
		
		Student s = new Student("A123");
		Student s1 =  new Student("A123");
		
		System.out.println(s.equals(s1));

		Map<Student, ReportCard> map =  new HashMap<Student, ReportCard>();
		
		map.put(s, new ReportCard());
		map.put(s1, new ReportCard());
		
		System.out.println(map.size());
	}

}
