
public class Student {

	String id;

	public Student(String id) {
		this.id = id;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}
	
	public boolean equals(Object o) {
		if(o != null && o instanceof Student) {
			String id = ((Student)o).getId();
			if(id != null && id.equals(this.getId())) {
				return true;
			}
		}
		
		return false;
	}
	
	public int hashCode() {
		return this.id.hashCode();
	}

}
