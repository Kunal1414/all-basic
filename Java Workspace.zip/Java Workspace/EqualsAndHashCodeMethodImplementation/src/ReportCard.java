
public class ReportCard {

	private int MathScore;
	
	public ReportCard() {
		this.MathScore = (int)((Math.random()*101)+1); 
	}

	public int getMathScore() {
		return MathScore;
	}

	public void setMathScore(int mathScore) {
		MathScore = mathScore;
	}
	
	
}
