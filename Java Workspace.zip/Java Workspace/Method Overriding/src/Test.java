
class Base
{
public Object display(String obj)
{
System.out.println("Base.display() " + obj);
return "0";
}
}
class Derived extends Base
{
@Override
public String display(String obj)
{
System.out.println("Derived.display() " + obj);
return "Derived";
}
}
public class Test {
public static void main(String[] args) {
Base baseRef = new Derived();
// Due to dynamic binding, will call the derived class
// display() function
String data = (String)baseRef.display("test");
System.out.println(data);
}
}