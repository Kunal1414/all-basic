
public class A {

	public A() {
		
	}
	
	public void m1() {
		System.out.println("in parent");
	}
}
