
public class B extends A {

/*	public void m1() {
		System.out.println("in child");
	}*/
	
	public static void main(String[] args) {
		
		B a =  new B();
		a.m1();
	}
}
