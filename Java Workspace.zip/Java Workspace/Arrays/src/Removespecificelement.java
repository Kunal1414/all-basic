import java.util.Scanner;

public class Removespecificelement {

	public static void main(String[] args) {
		
		
		 int[] my_array = {25, 14, 56, 15, 36, 56, 77, 18, 29, 49};
		 
		 System.out.println("reomve the elemet at index 2");
		 
		 int removedindex = 1;
		 
		 for (int i = removedindex; i < my_array.length-1; i++) {
			 my_array[i] = my_array[i+1];
		}
		 
		 System.out.println("after removing the element at index 2");
		 for (int i = 0; i < my_array.length-1; i++) {
			System.out.print(my_array[i] + " ");
		}

	}

}
