
public class arraycontainsspecificvalue {

	public static void main(String[] args) {
		
		int[] my_array1 = {1789, 2035, 1899, 1456, 2013, 
	            1458, 2458, 1254, 1472, 2365, 
	            1456, 2265, 1457, 2456};
		
		int num = 12544;
		int count = 0;
		
		for (int i = 0; i < my_array1.length; i++) {
			
			if(my_array1[i] == num) {
				System.out.println("Array contains the value " + num);
				count++;
			}
		}
		
		if(count==0) {
			System.out.println("Array doest contains the value " + num);
		}

	}

}
