import java.util.Arrays;

public class reverseanarrayofintegervalues {

	public static void main(String[] args) {

		int[] my_array = {25, 14, 56, 15, 36, 56, 77, 18, 29, 49};
		
		System.out.println(my_array.length);
		
		int[] reverse = new int[my_array.length];
		
		int j = my_array.length;
		
		for (int i = 0; i < reverse.length; i++) {
			
			reverse[i] = my_array[j-1];
			j = j-1;
			
		}
		
		
		System.out.println("original array " + Arrays.toString(my_array));
		
		System.out.println(" reverse array " + Arrays.toString(reverse));

	}

}
