
public class InsertionSort {

	public static void main(String[] args) {
		
		
		
		int arr[] = {3,60,35,2,45,320, 45, 5, 5};
		
	
	     int n = arr.length;
	     
	     for (int i = 0; i < arr.length; i++) {
			System.out.print(" " + arr[i]);
		}
	     
	     System.out.println();
	     System.out.println("after insertion sorting");
		
		int temp, j;
		
		for (int i = 1; i <n; i++) {
			
			temp = arr[i];
			j = i;
			while (j> 0 && arr[j-1] > temp) {
				arr[j] = arr[j-1];
				j = j-1;
				
			}
			arr[j] = temp;
			
		}
		
		  for (int i = 0; i < arr.length; i++) {
				System.out.print(" " + arr[i]);
			}
		
		
		

	}

}
