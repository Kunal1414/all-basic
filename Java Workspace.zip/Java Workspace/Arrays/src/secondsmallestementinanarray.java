
public class secondsmallestementinanarray {

	public static void main(String[] args) {

		int arr[] = { 14, 46, 47, 86, 92, 52, 48, 36, 66, 85 };
		
		int samllest =  Integer.MAX_VALUE;
		int secondsmallest = Integer.MAX_VALUE;
		
		
		for (int i = 0; i < arr.length; i++) {
			
			if(arr[i] < samllest) {
				samllest = arr[i];	
			}
			
			if(arr[i] > samllest && arr[i] < secondsmallest) {
				secondsmallest = arr[i];
			}
			
		}
		
		System.out.println("Second smallest number : " + secondsmallest);
		
		
	}

}
