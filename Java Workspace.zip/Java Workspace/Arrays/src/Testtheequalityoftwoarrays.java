
public class Testtheequalityoftwoarrays {

	public static void main(String[] args) {
		
		int[] array1 =  {2, 5, 7, 9, 11};
		int[] array2 =  {2, 5, 7, 9, 11};
		
		boolean equal = true;
		
		if(array1.length == array2.length) {
			
			for (int i = 0; i < array2.length; i++) {
				if(array1[i]!=array2[i]) {
					equal = false;
				}
			}
		}
		
		
		if(equal){
			System.out.println("both the arrays are identical");
		}else {
			System.out.println("both the arrays are not identical");
		}

	}

}
