import java.util.Arrays;

public class Removeduplicateelementsfromanarray {

	public static void main(String[] args) {

		int[] my_array = {1, 2, 5, 5, 6, 6, 7, 2};
		
		System.out.println("original array : " + Arrays.toString(my_array));
		Arrays.sort(my_array);
		System.out.println("original array : " + Arrays.toString(my_array));
		int []temp = new int[my_array.length];
		
		int j = 0;
		
		for (int i = 0; i < my_array.length-1; i++) {
			if(my_array[i]!=my_array[i+1]) {
				temp[j] = my_array[i];
				j = j+1;
			}
		}
		temp[j++] = my_array[my_array.length-1];
		System.out.println("after removing the duplicates array : " + Arrays.toString(temp));
		System.out.println(j);
		int []new_array = new int[j];
		for (int i = 0; i < j; i++) {
			new_array[i] = temp[i];
		}
		
		
		System.out.println("after removing the duplicates array : " + Arrays.toString(new_array));
	}

}
