
public class missingnumberinanarray {

	public static void main(String[] args) {
		
		int arr[] = {1, 2,3 ,4 ,5,6 ,8, 7};
		
		int n =  arr.length;
		System.out.println("n " + n);
		int total = (n+1) * (n+2) / 2;
		System.out.println("total " + total);
		
		int sum = 0;
		
	//	System.out.println(n  + " " + total);
		
		for (int i = 0; i < arr.length; i++) {
			sum = sum + arr[i];
		}
		System.out.println("Sum " + sum);
		System.out.println("the misisng number in array is " +  (total - sum));
		
	}

}
