import java.util.Arrays;

public class insertanelementspecificposition {

	public static void main(String[] args) {
	
		
		int[] my_array = {25, 14, 56, 15, 36, 56, 77, 18, 29, 49};
		
		System.out.println("original array " + Arrays.toString(my_array));
		System.out.println("insert 20 at position 4");
		int k = 20;
		int index = 4;
		
		for (int i = my_array.length-1; i > index; i--){
			my_array[i] = my_array[i-1];
		}
		my_array[index-1] = k;
		
		System.out.println("array after adding array " + Arrays.toString(my_array));
	}

}
