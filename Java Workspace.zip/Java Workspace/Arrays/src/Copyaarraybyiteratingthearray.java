import java.util.Arrays;

public class Copyaarraybyiteratingthearray {

	public static void main(String[] args) {
		
		int[] my_array = {25, 14, 56, 15, 36, 56, 77, 18, 29, 49};
		
		int []newarray = new int[my_array.length];
		
		System.out.println("old array " + Arrays.toString(my_array));
		
		for (int i = 0; i < my_array.length; i++) {
			newarray[i] = my_array[i];
		}
		
		System.out.println("New array " + Arrays.toString(newarray));
	}

}
