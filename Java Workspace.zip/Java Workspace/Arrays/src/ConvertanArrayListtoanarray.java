import java.util.ArrayList;
import java.util.Arrays;

public class ConvertanArrayListtoanarray {

	public static void main(String[] args) {
		
		
		ArrayList<String> list = new ArrayList<String>();
		list.add("java");
		list.add("PHP");
		list.add("C#");
		list.add("C++");
		list.add("Perl");
		
		String []myarray = new String[list.size()];
		
		for (int i = 0; i < myarray.length; i++) {
			myarray[i] = list.get(i);
		}
		
		for (int i = 0; i < myarray.length; i++) {
			System.out.print(" " + myarray[i]);
		}
		
		// uisng APi
		String []myarray1 = new String[list.size()];
		
		list.toArray(myarray1);		
		
		System.out.println("new array  : " + Arrays.toString(myarray1));
	}

}
