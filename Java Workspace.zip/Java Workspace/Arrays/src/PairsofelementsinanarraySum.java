
public class PairsofelementsinanarraySum {

	public static void main(String[] args) {
	
		int arr[] = {2, 7, 4, -5, 11, 5, 20};
		
		int inuputsum = 15;
		System.out.println("Pairs of elements and their sum : ");
		for (int i = 0; i < arr.length; i++) {
			
			for (int j = i+1; j < arr.length; j++) {
				
				if(arr[i] + arr[j] == inuputsum) {
					System.out.println(arr[i] + " + " + arr[j] + " = " + inuputsum);
				}
			}
		}
	}

}
