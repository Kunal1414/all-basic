
public class UseSimpleArray {

	public static void main(String[] args) {
		
		int  x = 1;
		int a[] = new int[5];
		
		for (int i = 0; i < 5; i++) {
			a[i] = x;
			x++;
		}
		
		System.out.println("aray elements are");
		
		for (int i = 0; i < 5; i++) {
			System.out.println(" " + a[i]);
		}


	}

}
