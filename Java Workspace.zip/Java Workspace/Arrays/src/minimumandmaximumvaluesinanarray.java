
public class minimumandmaximumvaluesinanarray {

	public static void main(String[] args) {
	
		int[] my_array = {25, 14, 56, 15, 36, 56, 77, 18, 29, 49};
		
		int max = maxvalueinrray(my_array);
		
		System.out.println("the max value in array is : " + max);
		
        int min = minvalueinrray(my_array);
		
		System.out.println("the min value in array is : " + min);
		
		
	}
	
	
	public static int minvalueinrray(int[] arr) {
		int min = arr[0];
		
		
		for (int i = 0; i < arr.length; i++) {
			if(arr[i] < min) {
				min = arr[i];
			}
		}
		return min;
		
	}
	
	public static int maxvalueinrray(int[] arr) {
		int max = arr[0];
		
		
		for (int i = 0; i < arr.length; i++) {
			if(arr[i] > max) {
				max = arr[i];
			}
		}
		return max;
		
	}

}
