
public class FibonacciseriesusingArray {

	public static void main(String[] args) {
		
		
		int n, i;
		
		int a[] = new int[20];
		//n = Integer.parseInt(args[0]);
		n = 10;
		a[0] = 1;
		a[1] = 2;
		
		for (int j = 2; j < n; j++) {
			a[j] = a[j-1] + a[j-2];
		}
		
		for (int j = 0; j < n; j++) {
			System.out.println(a[j]);
		}
	}
}
