import java.util.ArrayList;
import java.util.Arrays;

public class ConvertanarraytoArrayList {

	public static void main(String[] args) {
		
		
		String[]  my_array = new String[] {"Python", "JAVA", "PHP",  "Perl", "C#", "C++"};
		
		ArrayList<String> list =  new ArrayList<String>(Arrays.asList(my_array));
		
		System.out.println(list);
		
		ArrayList<String> list2 =  new ArrayList<String>();
		
		
		for (int i = 0; i < my_array.length; i++) {
			list2.add(my_array[i]);
		}
 
		System.out.println(list2);
	}

}
