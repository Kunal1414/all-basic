import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MapEntrySet {

	public static void main(String[] args) {
		
		HashMap<String, String> hm = new HashMap<String, String>();
		hm.put("a", "A");
		hm.put("b", "B");
		hm.put("d", "C");
	String returnvalue = 	hm.put("d", "D");
	
	System.out.println("returnvalue : " + returnvalue);
		
		System.out.println(hm);
		
		/*for (Map.Entry<String, String> entry : hm.entrySet()) {
			System.out.println(entry.getKey() + " " + entry.getValue());
		}*/
		
		Set s = hm.keySet();
		Iterator it = s.iterator();
		
		while (it.hasNext()) {
			String str = (String) it.next();
			System.out.println("key : " + str + " " + "value : " + hm.get(str));
			
			
		}
		
		

	}

}
