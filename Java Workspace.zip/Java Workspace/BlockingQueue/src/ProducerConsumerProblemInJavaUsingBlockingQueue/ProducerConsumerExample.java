package ProducerConsumerProblemInJavaUsingBlockingQueue;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.LinkedBlockingQueue;

public class ProducerConsumerExample {

	public static void main(String[] args) {
		
		BlockingQueue<Integer> queue =new LinkedBlockingQueue<Integer>();
		
		Thread t1 = new Thread(new Producer(queue));
		
		Thread t2 =  new Thread(new Consumer(queue));
		
		t1.start();
		t2.start();
	}

}
