
public class Reportcard {

	private int mathScore;
	
	public Reportcard() {
		this.mathScore = (int)((Math.random()*101)+1);
	}

	public int getMathScore() {
		return mathScore;
	}

	public void setMathScore(int mathScore) {
		this.mathScore = mathScore;
	}
	
	
}
