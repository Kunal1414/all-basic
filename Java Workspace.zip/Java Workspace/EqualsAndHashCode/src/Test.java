import java.util.HashMap;
import java.util.Map;

public class Test {

	public static void main(String[] args) {
		
		Student s1 = new Student("ABC");
		Student s2 = new Student("ABC");
		
		System.out.println(s1.equals(s2));
		
		
		Map<Student, Reportcard> map = new HashMap<Student, Reportcard>();
		
		map.put(s1, new Reportcard());
		
		map.put(s2, new Reportcard());
		
		System.out.println("----------------------");
		
		System.out.println(map);
		
		System.out.println(map.size());

	}

}
