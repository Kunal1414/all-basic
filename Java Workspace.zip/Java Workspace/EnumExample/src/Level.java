
public enum Level {

	HIGH,
	MEDIUM,
	LOW
}
