import java.util.Collections;

public class Enumtest {

	public static void main(String[] args) {
		
		Level level1 = Level.HIGH;
		
		System.out.println(Level.MEDIUM);
		
		for (Level level : Level.values()) {
		    System.out.println(level);
		}

		
		
	}

}
