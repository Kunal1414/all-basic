
public class Test {

	public static void main(String[] args) {
		
		int result = m1();
		System.out.println(result);

	}
	
	public static int m1() {

		try {
			int i = 10/10;
			return 1;
		
		} catch (Exception e) {
			return 2;
		}
		finally {
			return 5;
		}
	}

}
