
public class HandlingNullPointerException {

	public static void main(String[] args) {

try {
	String str = null;
	System.out.println(str.substring(0));
} catch (NullPointerException e) {
	System.out.println("handel null pointer exception");
	e.printStackTrace();
}

	}

}
