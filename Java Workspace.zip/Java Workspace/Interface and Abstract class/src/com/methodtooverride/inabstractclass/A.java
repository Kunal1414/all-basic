package com.methodtooverride.inabstractclass;

public interface A {

	void m1();
	
}
