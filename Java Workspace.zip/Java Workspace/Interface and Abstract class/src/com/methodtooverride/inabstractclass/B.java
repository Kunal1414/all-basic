package com.methodtooverride.inabstractclass;

public abstract  class B implements A{


}
