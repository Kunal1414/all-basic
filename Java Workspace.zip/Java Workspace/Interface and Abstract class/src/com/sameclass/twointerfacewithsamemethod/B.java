package com.sameclass.twointerfacewithsamemethod;

public interface B {
	
	void m1();
	
}
