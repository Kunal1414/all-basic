package com.sameclass.twointerfacewithsamemethod;

public interface A {

	void m1();
}
