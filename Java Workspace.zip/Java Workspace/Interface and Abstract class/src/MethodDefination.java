
public interface MethodDefination {

	
	void methodOne();
    void methodTwo();
    void methodThree(); 
    
}
