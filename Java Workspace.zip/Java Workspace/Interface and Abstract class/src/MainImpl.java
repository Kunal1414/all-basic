
public class MainImpl  extends MethodImplAbstract{

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	@Override
	public void methodTwo() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void methodThree() {
		// TODO Auto-generated method stub
		
	}

}
