
public abstract class MethodImplAbstract  implements MethodDefination{

	public static void main(String[] args) {


	}

	@Override
	public void methodOne() {
		// TODO Auto-generated method stub
		
	}


	public abstract void methodTwo();

	
	public abstract void methodThree();

}
