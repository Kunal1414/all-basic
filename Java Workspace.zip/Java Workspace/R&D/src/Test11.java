
public class Test11 {

	public static void main(String[] args) {

int i = m1();
	}
	
	public static int m1() {
		return 2599;
	}

}
