
public class C extends B {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		C c  = (C)new B();
		
		B  b  =  new C();
	}

}
