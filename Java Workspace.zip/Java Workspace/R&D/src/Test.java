
public class Test {

	public static void main(String[] args) {
		
		int arr[] = {1,6,0,5,8,0,9,0};
		
		for(int i = 0; i<arr.length - 1; i++) {
			if(arr[i]==0) {
				int temp = arr[i];
				arr[i] = arr[i+1];
				arr[i+1] = temp;
				i++;
			}
			System.out.print(arr[i]);
		}
			System.out.println();
			for (int j = 0; j < arr.length - 1; j++) {
				System.out.print(arr[j]);
			}
		}

	}


