import java.util.Arrays;
import java.util.List;

import javax.print.attribute.HashDocAttributeSet;

public class TryAndError {

	public static void abc() {
		System.out.println("in static");
	}
	
	public static void main(String[] args) {
		
		/*String[]  wordArray =  {"Love Yourself"  , "Alive is Awesome" , "Be in present"};
		List wordList =  Arrays.asList(wordArray);
		System.out.println(wordList);


		int i = 2306996 & 15;
		
		System.out.println(i);
		
		System.out.println("KING".hashCode() & 15);*/ 
		
		
		int i = 2 - 2 * 3 + 3;
		
		System.out.println(i);
		
		TryAndError t =  null;
		t.abc();
	}

}
