package com.enumtest;

public enum Command {
	
	CREATE_PARKING_LOT,
	PARK,
	LEAVE,
	STATUS,
	NOT_AVAILABLE,
	VEHICLE_ALREADY_EXIST,
	NOT_FOUND;
	/*NOT_AVAILABLE(-1),
	VEHICLE_ALREADY_EXIST(-1),
	NOT_FOUND(-1);*/
	
	private int value;
	private Command(int value) { this.value = value; }
	
	private Command() {
		
	}

}
