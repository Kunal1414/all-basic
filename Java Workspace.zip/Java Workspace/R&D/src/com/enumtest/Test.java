package com.enumtest;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;

public class Test {

	 
	
	public static void main(String[] args) {

	
		Map<Integer, Optional<Car>> map = new ConcurrentHashMap<>();
		
		Car car1 = new Car("park KA-01-HH-1234");
		map.put(1, Optional.of(car1));
		Car car2 = new Car("park KA-01-HH-1234");
		if(map.containsValue(Optional.of(car2))) {
			System.out.println("data already present");
		}else {
			map.put(2, Optional.of(car2));
			System.out.println("added");
		}
		
		
		
		System.out.println(map);
		  System.out.println(map.containsValue(Optional.of(car2)));
	}

}
