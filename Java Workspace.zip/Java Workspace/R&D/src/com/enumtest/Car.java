package com.enumtest;

public class Car {
	
private String	registrationNo	= null;

	
	public Car(String registrationNo)
	{
		this.registrationNo = registrationNo;

	}
	
	public String getRegistrationNo() {
		return registrationNo;
	}


	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}


	@Override
	public String toString()
	{
		return "registrationNo=" + registrationNo ;
	}

}
