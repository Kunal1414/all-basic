package com.test;

public class Address {
 
	String flatno;
	String streetname;
	String city;
	public Address(String flatno, String streetname, String city) {
		super();
		this.flatno = flatno;
		this.streetname = streetname;
		this.city = city;
	}
	
	
}
