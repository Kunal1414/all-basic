package com.test;

public class MainApp {

	public static void main(String[] args) {

		Address a1 =  new Address("501", "abc", "pune");
		
		emp  e1 = new emp(1, "kunal", a1);
		e1.address.hashCode();
		
		
		int i1 = 150;
		byte b1 = (byte) i1;
		System. out. println("int value: " + i1); // prints 10. 
		System. out. println("Converted byte value: " + b1); // prints 10.

	}

}
