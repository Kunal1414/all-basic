package com.test;

public class emp {
	
	public int id;
	public String name;
	Address address;
	public emp(int id, String name, Address address) {
		super();
		this.id = id;
		this.name = name;
		this.address = address;
	}
	
	
	
	

}
