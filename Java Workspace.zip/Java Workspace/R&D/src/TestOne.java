
public class TestOne {

	public static void main(String[] args) {

int i =10;
int j = 20;

int k = i | j;
System.out.println(k);

 Integer q = 14;
 System.out.println(q.valueOf(i));
 

	}

}
