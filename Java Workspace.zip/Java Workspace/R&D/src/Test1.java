
public class Test1 {

	public static void main(String[] args) {
		
		System.out.println("Hello World!");
		Integer id = 10;
		if(id.toString().matches("[0-9]+")) {
			System.out.println("true");
		}else {
			System.out.println("false");
		}
		
	}

}
