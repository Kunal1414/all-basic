import java.util.Arrays;

public class TestOne {

	public static void main(String[] args) {
		
		int array[] = {2,1,4,3,7,5,6,9};
		Arrays.sort(array);
		int data = 7;
		
		binarySearch(array, data);
	}
	
	public static void binarySearch(int[] array, int data) {
		
		int length =  array.length;
		int first = 0;
		int last = length-1;
		int mid;
		
		while(first<=last) {
			mid = (first+last)/2;
			if(array[mid]<data) {
				first = mid + 1;
			}else if(array[mid]==data) {
				System.out.println("Element " + data + " found at index " + mid);
				break;
			}else {
				last = mid-1;
			}
			mid= (first+last)/2;
			
		}
		
		if(first>last) {
			System.out.println("Element is not presnt in the list");
		}
	}

}
