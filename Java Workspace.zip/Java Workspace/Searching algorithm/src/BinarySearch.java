import java.util.Arrays;

public class BinarySearch {

 

    public static void main(String[] args) {
        int array[] = {2, 4, 12, 7, 10, 23, 45};
        int search = 23;
        Arrays.sort(array);

        binarySearch(array, search);

    }


    public static void binarySearch(int array[], int search) {
        int length = array.length;

        int first = 0;
        int last = length - 1;
        //Calculate midddle
        int middle = (first + last) / 2;

 
        while (first <= last) {
            //If search element is greater than middle element
            if (array[middle] < search) {
                first = middle + 1;
            } else if (array[middle] == search) {
                System.out.println(search + " found at location " + (middle + 1) + ".");
                break;
            } else {
                last = middle - 1;
            }

            middle = (first + last) / 2;
        }
        if (first > last) {
            System.out.println(search + " isn't present in the list.\n");
        }
    }
}