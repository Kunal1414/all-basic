import java.util.Arrays;

public class Test {

	public static void main(String[] args) {
		
		int array[] = {0,1,2,3,4,5,6,7};
		Arrays.sort(array);
		int data = 0;
		
		bianarySearch(array, data);
		
	}
	
	public static void bianarySearch(int[] array, int data) {
		
		int length = array.length;
		int first = 0;
		int last = length-1;
		
		int mid;
		while(first<=last) {
			mid = (first+last)/2;
			
			if(array[mid]<data) {
				first = mid+1;
			}else if(array[mid]==data) {
				System.out.println("Emelent " + data + " found at index " + mid );
				break;
			}else {
				last = mid-1;
			}
			
			mid = (first+last)/2;
			
		}
		if(first>last) {
			System.out.println("No element found in the array");
		}
	}
	

}
