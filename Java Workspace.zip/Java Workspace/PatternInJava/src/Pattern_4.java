
public class Pattern_4 {

	public static void main(String[] args) {
		
	    for (int i = 'A'; i <='E'; i++) {
			
	    	for (int j = 'A'; j <='E'; j++) {
				
	    		System.out.print((char)i);
			}
	    	System.out.println();
		}
		
		
	}

}
