
public class Pattern_8 {

	public static void main(String[] args) {
		
		for (int i = 'E'; i >='A'; i--) {
			for (int j = 1 ; j <=5; j++) {
				System.out.print((char)i);
			}
			System.out.println();
		}
	}

}
