
public class Pattern_7 {

	public static void main(String[] args) {
		
		for (int i = 5; 1<=i; i--) {
			for (int j = 5; 1<=j; j--) {
				
				System.out.print(j);
			}
			System.out.println();
		}

	}

}
