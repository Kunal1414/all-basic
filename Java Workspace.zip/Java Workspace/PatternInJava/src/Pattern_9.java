
public class Pattern_9 {

	public static void main(String[] args) {
		
		for (int i = 0; i <=5; i++) {
			
			for (int j = 'E'; j>='A'; j--) {
				System.out.print((char)j);
			}
			System.out.println();
		}

	}

}
