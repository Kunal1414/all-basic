
public class SingletonTest {

	
	private static SingletonTest instance;
	
	private SingletonTest() {
		
	}
	
	public synchronized static SingletonTest getInstance() {
		
		if(instance == null) {
			
			instance = new SingletonTest();
		}
		return instance;
	}
		
}

class SingletonTest2{
	
	private static SingletonTest2 singletonTest2;
	
	private SingletonTest2() {
		
	}
	
	public  static SingletonTest2 getInstance() {
		if(singletonTest2 == null) {
			
			synchronized (SingletonTest2.class) {
				if(singletonTest2 == null) {
					singletonTest2 =  new SingletonTest2();
				}
			}
			
		}
		return singletonTest2;
	}
}
