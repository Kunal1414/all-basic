import java.util.ArrayList;

public class Test {

	public static void main(String[] args) {
	
		ArrayList as = new ArrayList();
		as.add(1);
		as.add("a");
		as.add(1.5);
		
		System.out.println(as);

	}

}
