
public class TestForloop {

	public static void main(String[] args) {

    m1();

	}
	
	public static void m1() {
		int a = 0;
		for (int i = 0; i < 5; i++) {
			a = i;
			++i;
			System.out.println(i);
			m1();
		}
		System.out.println(a);
	}

}
