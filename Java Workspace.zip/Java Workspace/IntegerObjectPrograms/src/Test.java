
public class Test {

	public static void main(String[] args) {
		
		int i = 010;
		int j = 8;
		System.out.println(i);
		System.out.println(j);

	}

}
