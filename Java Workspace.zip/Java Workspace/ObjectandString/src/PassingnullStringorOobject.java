
public class PassingnullStringorOobject {

	public static void main(String[] args) {
		
		
		abc(null);

	}
	

	static public void abc(Object obj) {
		System.out.println("in object method");
	}
	
	static public void abc(String str) {
		System.out.println("in string method");
	}

}
