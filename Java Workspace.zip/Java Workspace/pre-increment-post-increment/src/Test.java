
public class Test {

	public static void main(String[] args) {
		/*int x =1;
        System.out.println(x);
        System.out.println(++x);// pre-increment
        System.out.println(x++);// post-increment
        System.out.println(x);*/
        
        
		boolean flag = true;
        System.out.println("Before return is executed");
        if(flag)
            return;
        
        System.out.println("After return is executed");
 

	}

}
