package com.hashmap.SortByValue;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class HashMapSortByValue {

	public static void main(String[] args) {
		
		 HashMap<String, Integer> hm = new HashMap<String, Integer>(); 
		  
	        // enter data into hashmap 
	        hm.put("Math", 98); 
	        hm.put("Data Structure", 85); 
	        hm.put("Database", 91); 
	        hm.put("Java", 95); 
	        hm.put("Operating System", 79); 
	        hm.put("Networking", 80); 
	        
	        Map<String, Integer> map = sortByValue(hm);
	        
	        for (Map.Entry<String, Integer>  entry: map.entrySet()) {
				System.out.println(entry.getKey() + " " + entry.getValue());
			}
	}

	public static HashMap<String, Integer> sortByValue(HashMap<String, Integer> hm){
		
		List<Map.Entry<String, Integer>> list = new LinkedList<>(hm.entrySet());
		ArrayList<Map.Entry<String, Integer>> list1 = new ArrayList<>(hm.entrySet()); 
		System.out.println("list " + list);
		Collections.sort(list, new Comparator<Map.Entry<String, Integer>>() {

			@Override
			public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
			
				return -o1.getValue().compareTo(o2.getValue());
			}
		});
		
		HashMap<String, Integer> temp = new LinkedHashMap<String, Integer>();
		for (Entry<String, Integer> entry : list) {
			temp.put(entry.getKey(), entry.getValue());
		}
			
		return temp;
		}
	
		
}
