
public class palindrome {

	public static void main(String[] args) {
		
		int n = 1234;
		
		int temp = 0;
		
		int copy = n;
		
		int rem;
		
		while(n!=0) {
			 
			rem = n%10;
			temp = (temp * 10) + rem;
			n = n/10;
			
		}
		
		System.out.println(temp);

	}

}
