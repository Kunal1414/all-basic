
public class CloseToZero {    
    public static void main(String[] args) {    
        int[] array = {0,2,3,4,5};    
        int targetnumber = 0;
        int closestnumber = array[0];
        for(int i=0; i<array.length; i++){
            targetnumber = array[i];
            if(targetnumber <= closestnumber){
                closestnumber = array[i];
            }
        }
        
        System.out.println("the closest number to zero is : " + closestnumber);
    }    
}