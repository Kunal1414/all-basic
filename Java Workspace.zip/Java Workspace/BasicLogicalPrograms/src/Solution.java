import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Solution {

	public static void main(String[] args) {

		solution("A586QK", "JJ653K");

	}

	static int solution(String a, String b) {

		char[] aa = a.toCharArray();
		char[] bb = b.toCharArray();

		for (int i = 0; i < aa.length; i++) {
			System.out.print(aa[i] + " ");
		}
		System.out.println();

		for (int i = 0; i < bb.length; i++) {
			System.out.print(bb[i] + " ");
		}
		System.out.println();

		List<Integer> listA = new ArrayList<>();
		for (char c : aa) {
			if (c == 'A') {
				listA.add(1);
			} else if (c == 'K') {
				listA.add(13);
			} else if (c == 'Q') {
				listA.add(12);
			} else if (c == 'J') {
				listA.add(11);
			} else if (c == 'T') {
				listA.add(10);
			} else {
				listA.add(Character.getNumericValue(c));
			}
		}

			List<Integer> listB = new ArrayList<>();
			for (char cc : bb) {
				if (cc == 'A') {
					listB.add(1);
				} else if (cc == 'K') {
					listB.add(13);
				} else if (cc == 'Q') {
					listB.add(12);
				} else if (cc == 'J') {
					listB.add(11);
				} else if (cc == 'T') {
					listB.add(10);
				} else {
					listB.add(Character.getNumericValue(cc));
				}
			}

			System.out.println(listA);
			System.out.println(listB);
			
			Integer[] integerA = new Integer[listA.size()];
			integerA = listA.toArray(integerA);
			
			Integer[] integerB = new Integer[listB.size()];
			integerB = listB.toArray(integerB);
			
			System.out.println(Arrays.toString(integerA));
			System.out.println(Arrays.toString(integerB));
			int max = 0;
			int count = 0;
			for (int j = 0; j < integerA.length; j++) {
				count = 0;
				for (int i = 0; i < integerB.length; i++) {
					if(integerA[j]>integerB[i]) {
						count++;
					}else if(integerA[j]==integerB[i]) {
						count--;
					}
				}
				if(count>max) {
					max = count;
				}
			}
			
			System.out.println("max " + max);
			System.out.println("count " + count);
			
			int min = 0;
			int count1 = 0;
			for (int j = 0; j < integerA.length; j++) {
				count1 = 0;
				for (int i = 0; i < integerB.length; i++) {
					if(integerA[j]<integerB[i]) {
						count1++;
					}else if(integerA[j]==integerB[i]) {
						count1--;
					}
				}
				if(count1>min) {
					min = count1;
				}
			}
			
			System.out.println("min " + min);
			System.out.println("count1 " + count1);
		
		return 0;
	}

}
