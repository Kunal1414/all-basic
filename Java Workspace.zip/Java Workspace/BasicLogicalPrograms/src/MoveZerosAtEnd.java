
public class MoveZerosAtEnd {

	public static void main(String[] args) {
		
		int []arr = {1,5,0,2,0,6,0,0,8,0,9,7};
		
		int i = 0;
		
		for (int j = 0; j < arr.length;) {
			if(arr[j]==0) {
				j++;
			}else {
				int temp = arr[i];
				arr[i] = arr[j];
				arr[j] = temp;
				j++;
				i++;
			}
		}
		
		for (int ii = 0; ii < arr.length; ii++) {
			System.out.print(arr[ii]);
		}
		
	}

}
