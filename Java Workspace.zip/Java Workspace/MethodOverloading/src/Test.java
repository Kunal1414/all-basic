
public class Test { // this is not method overloading as the return types are different

	public int add(int a, int b) {
		return a + b;
	}
	
	public void add(int a, int b, int c) {
		System.out.println(a + b + c);
	}
	
	
	public static void main(String[] args) {
		
		Test a  =  new Test();
		System.out.println(a.add(1 , 3));
		
	}
}
