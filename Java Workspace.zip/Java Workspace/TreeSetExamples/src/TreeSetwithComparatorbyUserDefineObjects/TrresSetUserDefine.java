package TreeSetwithComparatorbyUserDefineObjects;

import java.util.TreeSet;

public class TrresSetUserDefine {

	public static void main(String[] args) {
		
		TreeSet<Emp> t1 = new TreeSet<Emp>(new MyNameComp());
		TreeSet<Emp> t2 = new TreeSet<Emp>(new MySalaryComp());
		
		t1.add(new Emp("Ram",3000));
		t1.add(new Emp("John",6000));
		t1.add(new Emp("Crish",2000));
		t1.add(new Emp("Tom",2400));
		

		System.out.println(t1);
		
		System.out.println("--------------------------------------");
		
		t2.add(new Emp("Ram",3000));
		t2.add(new Emp("John",6000));
		t2.add(new Emp("Crish",2000));
		t2.add(new Emp("Tom",2400));
		System.out.println(t2);
	}

}
