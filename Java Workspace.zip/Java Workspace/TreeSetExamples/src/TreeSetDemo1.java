import java.util.Comparator;
import java.util.TreeSet;

public class TreeSetDemo1 {

	public static void main(String[] args) {
		
		/*TreeSet set = new TreeSet();
		
		set.add(4);
		set.add(2);
		set.add(9);
		set.add(6);
		
		System.out.println(set);
		
		
	TreeSet<Integer> set1 = new TreeSet<>(new Comparator<Integer>() {
       
		
		public int compare(Integer o1, Integer o2) {
			return -o1.compareTo(o2);
			}
		});
		
	set1.add(4);
	set1.add(2);
	set1.add(9);
	set1.add(6);
		
	System.out.println();
	
	System.out.println(set1);*/
	
	TreeSet<Integer> set5 = new TreeSet<>(new Comparator<Integer>() {
		
		public int compare(Integer i1, Integer i2) {
			return i2.compareTo(i1);
		}
	});
	
	set5.add(4);
	set5.add(2);
	set5.add(9);
	set5.add(6);
	System.out.println("=================");
	System.out.println(set5);
		
		
		

	}

}
