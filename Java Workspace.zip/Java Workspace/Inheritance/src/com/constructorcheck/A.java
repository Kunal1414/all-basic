package com.constructorcheck;

public class A {
	
	int i; 
	String str;
	public A(int i, String str) {
		super();
		this.i = i;
		this.str = str;
	}
	
	

}
