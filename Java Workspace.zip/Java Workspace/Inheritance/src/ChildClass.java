class ParentClass{
	
	public  void m1() {
		System.out.println("In m1 of parent class");
	}
	
}


public class ChildClass extends ParentClass {

	/*public void m1() {
		System.out.println("In m2 of child class");
	}*/
	
	static int o;
	
	public static void main(String[] args) {
	
		
		ParentClass c = new ChildClass();
		
		c.m1();
		
		ChildClass c1 = new ChildClass();
		
		c1.m1();
		
	}

}
